import { Text, View } from "react-native";

export default function ProfilePatient() {
  return (
    <View>
        <Text>ProfilePatient</Text>
    </View>
  )
}